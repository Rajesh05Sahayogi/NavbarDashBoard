import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import MainContent from './Components/MainContent'
import Header from './Components/Header'
import Layout from './Components/Layout'


function App() {
  return (
    <>
      {/* <Headers/>
    
      <MainContent/> */}
      <Layout/>
    </>
  )
}

export default App
